"""Configuration errors."""


class ConvivaTracingError(Exception):
    """Raised when the Conviva telemetry configuration is invalid or incomplete.

    Configuration is resolved eagerly -- before any OpenTelemetry global state
    is registered -- so raising leaves the process untouched.
    """
