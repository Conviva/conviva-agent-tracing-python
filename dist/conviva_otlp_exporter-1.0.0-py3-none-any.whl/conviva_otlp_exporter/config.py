"""Conviva gateway configuration.

The Python half of the contract in ``contract/config-contract.json``. Every
constant and every resolution rule here has a counterpart in
``packages/js/conviva-otlp-exporter/src/config.ts``; ``tests/test_contract.py``
drives both from the same fixture so they cannot drift apart again.
"""

import os
import re
from dataclasses import dataclass, field
from typing import Dict, Mapping, Optional
from urllib.parse import urlsplit, urlunsplit

from .errors import ConvivaTracingError

CUSTOMER_KEY_ENV = "CONVIVA_CUSTOMER_KEY"
PROJECT_ID_ENV = "CONVIVA_PROJECT_ID"
ENDPOINT_ENV = "CONVIVA_OTLP_ENDPOINT"

#: Header the Conviva gateway routes an export to a project by.
PROJECT_ID_HEADER = "X-Conviva-Project-Id"

#: Attribute carrying the same project id inside the telemetry payload.
PROJECT_ID_ATTRIBUTE = "cnv.project_id"

#: Attribute carrying the conversation id inside the telemetry payload.
CONVERSATION_ID_ATTRIBUTE = "cvx.conversation_id"

GATEWAY_DOMAIN = "agw.conviva.com"
TRACES_PATH = "/v1/traces"
# Not exported from the package: only traces are sent. Kept so an endpoint
# copied from a generic OTLP setup (``.../v1/metrics``) still resolves to the
# right base URL, and so the cross-language contract can assert them.
METRICS_PATH = "/v1/metrics"
LOGS_PATH = "/v1/logs"

#: Signal paths stripped from a configured endpoint so a base URL is recovered.
_SIGNAL_PATHS = (TRACES_PATH, METRICS_PATH, LOGS_PATH)

_DNS_LABEL = re.compile(r"^[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?$")


@dataclass(frozen=True)
class ResolvedConfig:
    """Where telemetry goes and what identifies it."""

    #: Base URL: no trailing slash, no signal path.
    endpoint: str
    traces_url: str
    headers: Dict[str, str] = field(default_factory=dict)
    customer_key: Optional[str] = None
    #: ``None`` when none was configured: the gateway then uses the default project.
    project_id: Optional[str] = None


def _first_non_empty(*values):
    for value in values:
        if isinstance(value, str) and value.strip() != "":
            return value.strip()
    return None


def parse_key_pairs(raw: str) -> Dict[str, str]:
    """Parse the OTLP ``key=value,key=value`` environment-variable format."""
    from urllib.parse import unquote

    parsed = {}
    for pair in raw.split(","):
        trimmed = pair.strip()
        if not trimmed:
            continue
        separator = trimmed.find("=")
        if separator <= 0:
            continue
        key = trimmed[:separator].strip()
        if not key:
            continue
        parsed[key] = unquote(trimmed[separator + 1 :].strip())
    return parsed


def normalize_endpoint(raw: str, source: str) -> str:
    """Normalize either a collector base URL or a full OTLP signal URL."""
    split = urlsplit(raw)

    if split.scheme not in ("http", "https"):
        if not split.scheme or not split.netloc:
            raise ConvivaTracingError('%s is not a valid URL: "%s".' % (source, raw))
        raise ConvivaTracingError(
            '%s must be an http or https URL, got "%s://".' % (source, split.scheme)
        )
    if not split.netloc:
        raise ConvivaTracingError('%s is not a valid URL: "%s".' % (source, raw))

    path = split.path.rstrip("/")
    for signal_path in _SIGNAL_PATHS:
        if path.endswith(signal_path):
            path = path[: -len(signal_path)]
            break

    return urlunsplit((split.scheme, split.netloc, path, "", "")).rstrip("/")


def resolve_config(
    customer_key: Optional[str] = None,
    project_id: Optional[str] = None,
    endpoint: Optional[str] = None,
    headers: Optional[Mapping[str, str]] = None,
    env: Optional[Mapping[str, str]] = None,
) -> ResolvedConfig:
    """Resolve the Conviva destination and routing headers.

    Endpoint precedence, highest first:

    1. the ``endpoint`` argument
    2. ``CONVIVA_OTLP_ENDPOINT``
    3. ``OTEL_EXPORTER_OTLP_TRACES_ENDPOINT``
    4. ``OTEL_EXPORTER_OTLP_ENDPOINT``
    5. derived -- ``https://<customer_key>.agw.conviva.com``

    Rungs 3 and 4 are what let a stock OpenTelemetry operator redirect
    telemetry to a local collector without knowing any Conviva-specific
    variable name.
    """
    env = os.environ if env is None else env

    # Optional. Without it there is no project header and no `cnv.project_id`,
    # and the gateway files the traces under the customer's default project.
    resolved_project_id = _first_non_empty(project_id, env.get(PROJECT_ID_ENV))

    resolved_customer_key = _first_non_empty(customer_key, env.get(CUSTOMER_KEY_ENV))

    override = _first_non_empty(
        endpoint,
        env.get(ENDPOINT_ENV),
        env.get("OTEL_EXPORTER_OTLP_TRACES_ENDPOINT"),
        env.get("OTEL_EXPORTER_OTLP_ENDPOINT"),
    )

    if override:
        if _first_non_empty(endpoint):
            source = '"endpoint"'
        elif _first_non_empty(env.get(ENDPOINT_ENV)):
            source = ENDPOINT_ENV
        elif _first_non_empty(env.get("OTEL_EXPORTER_OTLP_TRACES_ENDPOINT")):
            source = "OTEL_EXPORTER_OTLP_TRACES_ENDPOINT"
        else:
            source = "OTEL_EXPORTER_OTLP_ENDPOINT"
        resolved_endpoint = normalize_endpoint(override, source)
    else:
        if not resolved_customer_key:
            raise ConvivaTracingError(
                'Conviva customer key is required -- pass "customer_key", set %s, '
                "or configure %s." % (CUSTOMER_KEY_ENV, ENDPOINT_ENV)
            )
        if not _DNS_LABEL.match(resolved_customer_key):
            raise ConvivaTracingError(
                'Conviva customer key "%s" is not a valid hostname label -- '
                'it becomes the "<customer_key>.%s" subdomain.'
                % (resolved_customer_key, GATEWAY_DOMAIN)
            )
        resolved_endpoint = "https://%s.%s" % (resolved_customer_key, GATEWAY_DOMAIN)

    resolved_headers = {}
    raw_headers = env.get("OTEL_EXPORTER_OTLP_HEADERS")
    if raw_headers:
        resolved_headers.update(parse_key_pairs(raw_headers))
    raw_trace_headers = env.get("OTEL_EXPORTER_OTLP_TRACES_HEADERS")
    if raw_trace_headers:
        resolved_headers.update(parse_key_pairs(raw_trace_headers))
    if headers:
        resolved_headers.update({str(k): str(v) for k, v in headers.items()})

    # HTTP header names are case-insensitive but dict keys are not. Without
    # this delete, {"x-conviva-project-id": "wrong"} from the environment would
    # survive alongside the canonical key and the gateway could see either.
    # The project id comes from `project_id` / CONVIVA_PROJECT_ID only, so a
    # stray header is dropped even when no project is configured.
    for key in [k for k in resolved_headers if k.lower() == PROJECT_ID_HEADER.lower()]:
        del resolved_headers[key]
    if resolved_project_id:
        resolved_headers[PROJECT_ID_HEADER] = resolved_project_id

    return ResolvedConfig(
        customer_key=resolved_customer_key,
        project_id=resolved_project_id,
        endpoint=resolved_endpoint,
        traces_url=resolved_endpoint + TRACES_PATH,
        headers=resolved_headers,
    )
