"""The OTLP http/protobuf trace exporter pointed at the Conviva gateway."""

from .trace import create_trace_exporter

__all__ = ["create_trace_exporter"]
