"""The OTLP trace exporter."""

from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter

from ..config import ResolvedConfig


def create_trace_exporter(config: ResolvedConfig) -> OTLPSpanExporter:
    """Build the OTLP **http/protobuf** trace exporter for the Conviva gateway.

    The exporter is constructed here rather than delegated to a vendor SDK so
    the destination, protocol and routing header are all Conviva-owned. Vendor
    SDKs create ordinary OpenTelemetry spans and do not need their own
    exporter.

    ``endpoint`` is passed explicitly and therefore wins over the
    ``OTEL_EXPORTER_OTLP_*`` variables, which could otherwise redirect traces
    off the gateway after config resolution has already decided where they go.
    """
    return OTLPSpanExporter(endpoint=config.traces_url, headers=dict(config.headers))
