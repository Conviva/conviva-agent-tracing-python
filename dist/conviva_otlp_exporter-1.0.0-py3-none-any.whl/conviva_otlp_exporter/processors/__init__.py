"""Span processors that stamp the ids the Conviva gateway correlates on."""

from typing import List, Mapping, Optional, Sequence

from opentelemetry.sdk.trace import SpanProcessor

from ..config import ResolvedConfig
from .attributes import AttributeSpanProcessor
from .composite import CompositeSpanProcessor
from .conversation import (
    ASSOCIATION_PROPERTY_PREFIX,
    DEFAULT_BAGGAGE_KEYS,
    DEFAULT_SOURCE_ATTRIBUTES,
    GEN_AI_CONVERSATION_ID_ATTRIBUTE,
    ConversationIdSpanProcessor,
)
from .project_id import ProjectIdSpanProcessor

__all__ = [
    "ASSOCIATION_PROPERTY_PREFIX",
    "DEFAULT_BAGGAGE_KEYS",
    "DEFAULT_SOURCE_ATTRIBUTES",
    "GEN_AI_CONVERSATION_ID_ATTRIBUTE",
    "AttributeSpanProcessor",
    "CompositeSpanProcessor",
    "ConversationIdSpanProcessor",
    "ProjectIdSpanProcessor",
    "create_conviva_span_processors",
]


def create_conviva_span_processors(
    config: ResolvedConfig,
    conversation_id: Optional[str] = None,
    source_attributes: Optional[Sequence[str]] = None,
    baggage_keys: Optional[Sequence[str]] = None,
    attributes: Optional[Mapping[str, Optional[str]]] = None,
) -> List[SpanProcessor]:
    """The full Conviva processor stack, in the order it must run.

    Conversation first so ``cvx.conversation_id`` is resolved from whatever the
    instrumentation wrote; project id next; caller attributes last, since they
    are the most specific.

    Returned as a list rather than a composite so callers that own a
    ``TracerProvider`` can add them individually. Callers stuck with a
    single-processor API wrap them in :class:`CompositeSpanProcessor`.
    """
    processors: List[SpanProcessor] = [
        ConversationIdSpanProcessor(
            conversation_id=conversation_id,
            source_attributes=source_attributes,
            baggage_keys=baggage_keys,
        ),
    ]
    # No project id configured: no `cnv.project_id`, and the gateway uses the
    # customer's default project.
    if config.project_id:
        processors.append(ProjectIdSpanProcessor(config.project_id))

    if attributes:
        processors.append(AttributeSpanProcessor(attributes))

    return processors
