"""Per-span project attribution."""

from typing import Optional

from opentelemetry.context import Context
from opentelemetry.sdk.trace import ReadableSpan, Span, SpanProcessor

from ..config import PROJECT_ID_ATTRIBUTE


class ProjectIdSpanProcessor(SpanProcessor):
    """Adds the Conviva project id to every span without overwriting app data.

    Not redundant with the ``X-Conviva-Project-Id`` request header: the header
    plus a resource attribute alone was observed to produce HTTP 200 on every
    export with nothing visible downstream. Only the per-span attribute worked.
    """

    def __init__(self, project_id: str):
        self._project_id = project_id

    def on_start(self, span: Span, parent_context: Optional[Context] = None) -> None:
        attributes = span.attributes or {}
        if attributes.get(PROJECT_ID_ATTRIBUTE) is None:
            span.set_attribute(PROJECT_ID_ATTRIBUTE, self._project_id)

    def on_end(self, span: ReadableSpan) -> None:
        pass

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return True

    def shutdown(self) -> None:
        pass
