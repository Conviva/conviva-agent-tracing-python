"""Several span processors as one."""

from typing import Optional

from opentelemetry.context import Context
from opentelemetry.sdk.trace import ReadableSpan, Span, SpanProcessor


class CompositeSpanProcessor(SpanProcessor):
    """Runs several span processors as one.

    ``Traceloop.init()`` accepts a single ``processor``, so this is how
    Conviva's processors coexist with one the application passed in.
    Processors run in argument order; ``force_flush`` and ``shutdown`` fan out
    to all of them. ``None`` entries are dropped so callers can splice in
    optional processors without filtering at every call site.
    """

    def __init__(self, *processors: Optional[SpanProcessor]):
        self._processors = [p for p in processors if p is not None]

    def on_start(self, span: Span, parent_context: Optional[Context] = None) -> None:
        for processor in self._processors:
            processor.on_start(span, parent_context)

    def on_end(self, span: ReadableSpan) -> None:
        for processor in self._processors:
            processor.on_end(span)

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        # `all(...)` over a list comprehension, not a generator: every child
        # must be flushed even after one of them reports failure.
        return all([p.force_flush(timeout_millis) for p in self._processors])

    def shutdown(self) -> None:
        for processor in self._processors:
            processor.shutdown()
