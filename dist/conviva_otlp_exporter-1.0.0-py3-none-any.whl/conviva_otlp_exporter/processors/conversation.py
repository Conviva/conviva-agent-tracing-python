"""Conversation correlation.

Conviva groups spans into a conversation by a single attribute,
``cvx.conversation_id``. No instrumentation SDK writes that name: OpenLLMetry's
association properties land under
``traceloop.association.properties.session_id``, and other SDKs write
``session.id``. This processor closes the gap by copying whichever one is
present onto the name Conviva reads.

WHY A SPAN PROCESSOR, and why it must run after the SDK's own:

OpenLLMetry applies association properties in the ``on_start`` of its own
exporting processor, which is installed ahead of the one passed to
``Traceloop.init(processor=...)``. By the time this one runs the association
property is already on the span and can be read back off it. Reading rather
than re-deriving keeps one source of truth.

``on_start``, not ``on_end``: by ``on_end`` the span is read-only and the
exporting processor has already run.
"""

from typing import Optional, Sequence

from opentelemetry.baggage import get_baggage
from opentelemetry.context import Context
from opentelemetry.sdk.trace import ReadableSpan, Span, SpanProcessor

from ..config import CONVERSATION_ID_ATTRIBUTE

#: The OpenTelemetry GenAI semantic-convention name for the conversation id.
#: Written alongside ``cvx.conversation_id`` so a backend that maps the
#: standard name (to ``session_id``, for example) sees the same value.
GEN_AI_CONVERSATION_ID_ATTRIBUTE = "gen_ai.conversation.id"

#: Prefix OpenLLMetry gives every association property it writes onto a span.
ASSOCIATION_PROPERTY_PREFIX = "traceloop.association.properties."

#: Span attributes read as the conversation id, highest priority first.
#:
#: First entry is OpenLLMetry's association property; the other two are the
#: OpenTelemetry-native spellings that Langfuse and OpenInference emit.
DEFAULT_SOURCE_ATTRIBUTES = (
    ASSOCIATION_PROPERTY_PREFIX + "session_id",
    "session.id",
    "gen_ai.conversation.id",
)

#: Baggage keys read as the conversation id, highest priority first.
#:
#: ``c3.conv_id`` comes first: it is the conversation id the Conviva client
#: sensor puts in the ``baggage`` header, the same entry
#: ``conviva-agent-traces-connector`` copies onto spans.
DEFAULT_BAGGAGE_KEYS = ("c3.conv_id", "conversation_id", "session_id", "langfuse_session_id")


def _usable(value) -> Optional[str]:
    if isinstance(value, str) and value.strip() != "":
        return value.strip()
    return None


class ConversationIdSpanProcessor(SpanProcessor):
    """Writes ``cvx.conversation_id`` and ``gen_ai.conversation.id`` onto every
    span that can be correlated.

    Resolution order, first hit wins:

    1. the explicit ``conversation_id`` argument
    2. ``source_attributes``, read off the span
    3. ``baggage_keys``, read off the parent context

    Neither attribute is ever overwritten -- an application that set one
    deliberately has made a more specific statement than anything this
    processor can infer. An existing ``cvx.conversation_id`` is also the value
    used for a missing ``gen_ai.conversation.id``, so the two cannot disagree
    unless the application made them.
    """

    def __init__(
        self,
        conversation_id: Optional[str] = None,
        source_attributes: Optional[Sequence[str]] = None,
        baggage_keys: Optional[Sequence[str]] = None,
    ):
        self._conversation_id = conversation_id
        self._source_attributes = tuple(
            DEFAULT_SOURCE_ATTRIBUTES if source_attributes is None else source_attributes
        )
        self._baggage_keys = tuple(
            DEFAULT_BAGGAGE_KEYS if baggage_keys is None else baggage_keys
        )

    def on_start(self, span: Span, parent_context: Optional[Context] = None) -> None:
        attributes = span.attributes or {}
        has_conviva = attributes.get(CONVERSATION_ID_ATTRIBUTE) is not None
        has_gen_ai = attributes.get(GEN_AI_CONVERSATION_ID_ATTRIBUTE) is not None
        if has_conviva and has_gen_ai:
            return

        resolved = _usable(attributes.get(CONVERSATION_ID_ATTRIBUTE))
        if resolved is None:
            resolved = self._resolve(attributes, parent_context)
        if resolved is None:
            return

        if not has_conviva:
            span.set_attribute(CONVERSATION_ID_ATTRIBUTE, resolved)
        if not has_gen_ai:
            span.set_attribute(GEN_AI_CONVERSATION_ID_ATTRIBUTE, resolved)

    def _resolve(self, attributes, parent_context) -> Optional[str]:
        explicit = _usable(self._conversation_id)
        if explicit is not None:
            return explicit

        for attribute in self._source_attributes:
            value = _usable(attributes.get(attribute))
            if value is not None:
                return value

        for key in self._baggage_keys:
            value = _usable(get_baggage(key, context=parent_context))
            if value is not None:
                return value

        return None

    def on_end(self, span: ReadableSpan) -> None:
        """Export is the exporting processor's job; this one only decorates."""

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        """Nothing is buffered here."""
        return True

    def shutdown(self) -> None:
        """Nothing to release."""
