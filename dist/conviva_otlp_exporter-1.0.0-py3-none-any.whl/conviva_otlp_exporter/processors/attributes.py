"""Fixed attributes on every span."""

from typing import Mapping, Optional

from opentelemetry.context import Context
from opentelemetry.sdk.trace import ReadableSpan, Span, SpanProcessor


class AttributeSpanProcessor(SpanProcessor):
    """Stamps a fixed set of attributes onto every span.

    ``None`` and empty values are dropped once at construction rather than
    re-checked per span, so the hot path is a single ``set_attributes`` call.
    """

    def __init__(self, attributes: Mapping[str, Optional[str]]):
        self._attributes = {
            key: value
            for key, value in attributes.items()
            if isinstance(value, str) and value != ""
        }

    def on_start(self, span: Span, parent_context: Optional[Context] = None) -> None:
        if not self._attributes:
            return
        span.set_attributes(self._attributes)

    def on_end(self, span: ReadableSpan) -> None:
        pass

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return True

    def shutdown(self) -> None:
        pass
