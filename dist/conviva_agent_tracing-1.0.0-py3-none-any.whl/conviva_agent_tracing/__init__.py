"""``conviva-agent-tracing`` -- OpenLLMetry on the Conviva transport layer.

Auto-instruments the LLM, vector-DB and framework libraries OpenLLMetry
supports, and exports the resulting spans to the Conviva agent gateway over
OTLP http/protobuf with ``cvx.conversation_id`` and ``cnv.project_id`` stamped
on every span, along with the Conviva client's ``c3.*`` baggage entries. Traces
only -- no metrics or logs are exported.

Call :func:`init` once, before importing the libraries you want instrumented.

The Python mirror of ``@convivainc/agent-tracing``: same shape, ``snake_case``
names.
"""

import logging
import os
from collections.abc import Mapping, Sequence
from typing import Any

from conviva_agent_traces_connector import (
    BaggageSpanProcessor,
    ensure_baggage_propagator,
)
from conviva_agent_traces_connector import Config as BaggageConfig
from conviva_otlp_exporter import (
    CONVERSATION_ID_ATTRIBUTE,
    CUSTOMER_KEY_ENV,
    ENDPOINT_ENV,
    GATEWAY_DOMAIN,
    PROJECT_ID_ATTRIBUTE,
    PROJECT_ID_ENV,
    PROJECT_ID_HEADER,
    TRACES_PATH,
    AttributeSpanProcessor,
    CompositeSpanProcessor,
    ConversationIdSpanProcessor,
    ConvivaTracingError,
    ProjectIdSpanProcessor,
    ResolvedConfig,
    create_conviva_span_processors,
    create_trace_exporter,
    resolve_config,
)
from opentelemetry.sdk.trace import SpanProcessor
from opentelemetry.sdk.trace.export import BatchSpanProcessor, SimpleSpanProcessor
from traceloop.sdk import Traceloop
from traceloop.sdk.decorators import (
    aagent,
    agent,
    atask,
    atool,
    aworkflow,
    conversation,
    task,
    tool,
    workflow,
)
from traceloop.sdk.instruments import Instruments
from traceloop.sdk.tracing.manual import LLMMessage, LLMUsage, track_llm_call

__version__ = "1.0.0"

_logger = logging.getLogger(__name__)
_resolved: ResolvedConfig | None = None


#: Set to ``0``, ``false`` or ``no`` to keep prompts and completions off spans.
TRACE_CONTENT_ENV = "CONVIVA_TRACE_CONTENT"

#: OpenLLMetry's own equivalent, honoured when the Conviva one is unset.
_TRACELOOP_TRACE_CONTENT_ENV = "TRACELOOP_TRACE_CONTENT"


def _parse_bool(value: str | None) -> bool | None:
    # An empty variable reads as unset, not as false: `.env` files are full of
    # bare `SOME_FLAG=` lines, and this setting defaults to ON.
    if value is None or value.strip() == "":
        return None
    return value.strip().lower() in ("1", "true", "yes")


def _resolve_trace_content(explicit: bool | None, env: dict[str, str] | None = None) -> bool:
    """Whether prompts, completions and tool payloads are recorded on spans.

    Highest precedence first: the ``trace_content`` argument,
    ``CONVIVA_TRACE_CONTENT``, OpenLLMetry's ``TRACELOOP_TRACE_CONTENT``, then
    ``True``. The same order as the JS SDK.
    """
    env = os.environ if env is None else env
    for candidate in (
        explicit,
        _parse_bool(env.get(TRACE_CONTENT_ENV)),
        _parse_bool(env.get(_TRACELOOP_TRACE_CONTENT_ENV)),
    ):
        if candidate is not None:
            return candidate
    return True


def _disable_non_trace_signals(env: dict[str, str] | None = None) -> None:
    """Pin OpenLLMetry to traces only.

    The Conviva gateway exposes no metrics or logs endpoint yet. OpenLLMetry
    defaults ``TRACELOOP_METRICS_ENABLED`` to true and, when given a custom
    processor but no metric exporter, builds a metrics pipeline pointed at
    ``api_endpoint`` -- which would emit requests that can only fail. Explicit
    values are left alone, so a host application can still opt into its own
    pipelines, and flipping this is the switch that turns metrics and logs on
    once the gateway serves them.
    """
    env = os.environ if env is None else env
    env.setdefault("TRACELOOP_METRICS_ENABLED", "false")
    env.setdefault("TRACELOOP_LOGGING_ENABLED", "false")


def _keep_logs_off_the_gateway(
    options: Mapping[str, Any], env: dict[str, str] | None = None
) -> None:
    """Stop OpenLLMetry from sending logs to the Conviva gateway.

    With logging enabled and no logging exporter of its own, OpenLLMetry
    exports logs to ``api_endpoint`` -- which here is the gateway, and the
    gateway accepts traces only. Logs bound for a destination the application
    chose (``logging_exporter`` or ``TRACELOOP_LOGGING_ENDPOINT``) are left
    alone. Metrics need no equivalent: OpenLLMetry already disables them when
    it is handed a custom processor and no ``metrics_exporter``.
    """
    env = os.environ if env is None else env
    enabled = env.get("TRACELOOP_LOGGING_ENABLED", "false").strip().lower() == "true"
    if not enabled or options.get("logging_exporter") or env.get("TRACELOOP_LOGGING_ENDPOINT"):
        return
    _logger.warning(
        "TRACELOOP_LOGGING_ENABLED is set without a logging exporter or "
        "TRACELOOP_LOGGING_ENDPOINT; disabling it, because the Conviva gateway "
        "accepts traces only."
    )
    env["TRACELOOP_LOGGING_ENABLED"] = "false"


def init(
    app_name: str | None = None,
    customer_key: str | None = None,
    project_id: str | None = None,
    endpoint: str | None = None,
    headers: Mapping[str, str] | None = None,
    conversation_id: str | None = None,
    conversation_id_sources: Sequence[str] | None = None,
    conversation_id_baggage_keys: Sequence[str] | None = None,
    attributes: Mapping[str, str | None] | None = None,
    span_processors: list[SpanProcessor] | None = None,
    disable_batch: bool = False,
    baggage_config: BaggageConfig | None = None,
    trace_content: bool | None = None,
    **openllmetry_options: Any,
) -> ResolvedConfig:
    """Initialize Conviva tracing on top of OpenLLMetry.

    Every keyword not named above is passed through to ``Traceloop.init`` --
    ``instruments``, ``block_instruments``, ``sampler``, ``propagator``,
    ``resource_attributes`` and the rest.

    :param customer_key: defaults to ``CONVIVA_CUSTOMER_KEY``.
    :param project_id: defaults to ``CONVIVA_PROJECT_ID``. Optional: without
        one, the gateway files the traces under the customer's default project.
    :param span_processors: extra processors, composed after Conviva's own.
    :param trace_content: record prompts, completions and tool payloads on
        spans. Defaults to ``CONVIVA_TRACE_CONTENT``, then ``True``.
    :param baggage_config: which W3C baggage entries
        ``conviva-agent-traces-connector`` copies onto every span. Defaults to
        the Conviva client's ``c3.*`` entries (client, conversation and message
        ids).
    :param disable_batch: export each span as it ends instead of in batches.
        Handled here rather than passed through, because OpenLLMetry only
        consults its own ``disable_batch`` when it builds the default
        processor -- and this package always supplies one.
    :raises ConvivaTracingError: if neither a customer key nor an endpoint is
        set, or a value is malformed.

    Note that every span on the global tracer provider is exported, including
    spans from any host HTTP or database instrumentation -- OpenLLMetry
    installs no scope filter.
    """
    global _resolved

    if _resolved is not None:
        _logger.warning("Conviva tracing is already initialized; ignoring this init() call.")
        return _resolved

    # Validate before touching any global state, so a bad config is a clean
    # raise that leaves the process untouched.
    config = resolve_config(
        customer_key=customer_key,
        project_id=project_id,
        endpoint=endpoint,
        headers=headers,
    )

    _disable_non_trace_signals()

    # OpenLLMetry's Python instrumentations read the switch from the
    # environment only, so the resolved value is written there.
    os.environ[_TRACELOOP_TRACE_CONTENT_ENV] = str(_resolve_trace_content(trace_content)).lower()
    _keep_logs_off_the_gateway(openllmetry_options)

    exporter = create_trace_exporter(config)
    exporting_processor: SpanProcessor = (
        SimpleSpanProcessor(exporter) if disable_batch else BatchSpanProcessor(exporter)
    )

    conviva_processors = create_conviva_span_processors(
        config,
        conversation_id=conversation_id,
        source_attributes=conversation_id_sources,
        baggage_keys=conversation_id_baggage_keys,
        attributes=attributes,
    )

    # A SINGLE composite, never a list. OpenLLMetry chains its own on_start
    # around each processor it is given, and the order differs between the two
    # code paths: for a list it runs the processor first and OpenLLMetry's hook
    # second; for a single processor it runs OpenLLMetry's hook first. Only the
    # latter order works -- ConversationIdSpanProcessor reads the association
    # properties that hook writes, so it has to run after it.
    #
    # Passing `exporter=` alongside `processor=` is also not an option:
    # OpenLLMetry logs a warning and ignores the exporter. The pipeline is
    # assembled here instead.
    processor = CompositeSpanProcessor(
        BaggageSpanProcessor(baggage_config),
        *conviva_processors,
        *(span_processors or []),
        exporting_processor,
    )

    # Only pass app_name when we actually have one: OpenLLMetry otherwise
    # derives it from the process name, which is a better guess than any
    # constant this package could invent.
    resolved_app_name = app_name or os.getenv("OTEL_SERVICE_NAME")
    if resolved_app_name:
        openllmetry_options["app_name"] = resolved_app_name

    Traceloop.init(
        api_endpoint=config.endpoint,
        headers=dict(config.headers),
        processor=processor,
        # The prompt registry is a Traceloop-backend feature with no
        # counterpart on the Conviva gateway.
        traceloop_sync_enabled=openllmetry_options.pop("traceloop_sync_enabled", False),
        **openllmetry_options,
    )

    # After Traceloop.init, which replaces the global propagator when given a
    # `propagator`. This merges W3C baggage and trace context into whatever is
    # registered, so incoming `baggage:` headers reach the baggage processor.
    ensure_baggage_propagator()

    _resolved = config
    _logger.info(
        "Conviva exporting traces to %s (project %s).",
        config.traces_url,
        config.project_id or "default for this customer key",
    )
    return config


def get_config() -> ResolvedConfig | None:
    """The active configuration, or ``None`` before :func:`init`."""
    return _resolved


def force_flush() -> None:
    """Flush any spans still buffered in the batch processor."""
    if _resolved is None:
        return
    from traceloop.sdk.tracing.tracing import TracerWrapper

    if TracerWrapper.verify_initialized():
        TracerWrapper().flush()


def shutdown() -> None:
    """Flush pending spans before shutdown.

    OpenLLMetry keeps its tracer provider private and exposes no shutdown
    hook, so this drains the batch processor but leaves instrumentation
    installed -- tracing cannot be restarted in the same process. Same
    limitation as the JS wrapper; stated rather than papered over.
    """
    force_flush()


def set_association_properties(properties: Mapping[str, Any]) -> None:
    """Attach association properties to the current trace.

    ``session_id`` is the one Conviva cares about:
    :class:`ConversationIdSpanProcessor` reads it back off the span as
    ``cvx.conversation_id``.
    """
    Traceloop.set_association_properties(dict(properties))


def reset_for_testing() -> None:
    """Test seam: forget the cached config so a fresh :func:`init` can run."""
    global _resolved
    _resolved = None


__all__ = [
    # Conviva
    "BaggageConfig",
    "BaggageSpanProcessor",
    "Instruments",
    "LLMMessage",
    "LLMUsage",
    "TRACE_CONTENT_ENV",
    "CONVERSATION_ID_ATTRIBUTE",
    "CUSTOMER_KEY_ENV",
    "ENDPOINT_ENV",
    "GATEWAY_DOMAIN",
    "PROJECT_ID_ATTRIBUTE",
    "PROJECT_ID_ENV",
    "PROJECT_ID_HEADER",
    "TRACES_PATH",
    "AttributeSpanProcessor",
    "CompositeSpanProcessor",
    "ConversationIdSpanProcessor",
    "ConvivaTracingError",
    "ProjectIdSpanProcessor",
    "ResolvedConfig",
    "__version__",
    "create_conviva_span_processors",
    "create_trace_exporter",
    "ensure_baggage_propagator",
    "force_flush",
    "get_config",
    "init",
    "reset_for_testing",
    "resolve_config",
    "set_association_properties",
    "shutdown",
    # OpenLLMetry's manual-annotation surface, re-exported so applications
    # depend on this package alone.
    "aagent",
    "agent",
    "atask",
    "atool",
    "aworkflow",
    "conversation",
    "task",
    "tool",
    "track_llm_call",
    "workflow",
]
