"""The OTLP trace exporter."""

from __future__ import annotations

from collections.abc import Sequence

from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.trace.export import SpanExporter

from ..config import ResolvedConfig
from ..errors import ConvivaTracingError
from .mask import MaskFunction, MaskingSpanExporter


def create_trace_exporter(
    config: ResolvedConfig,
    mask: MaskFunction | None = None,
    mask_attributes: Sequence[str] | None = None,
) -> SpanExporter:
    """Build the OTLP **http/protobuf** trace exporter for the Conviva gateway.

    The exporter is constructed here rather than delegated to a vendor SDK so
    the destination, protocol and routing header are all Conviva-owned. Vendor
    SDKs create ordinary OpenTelemetry spans and do not need their own
    exporter.

    ``endpoint`` is passed explicitly and therefore wins over the
    ``OTEL_EXPORTER_OTLP_*`` variables, which could otherwise redirect traces
    off the gateway after config resolution has already decided where they go.

    :param mask: optional hook called for each content attribute just before
        export (see :class:`MaskingSpanExporter`). Off when ``None``: the plain
        ``OTLPSpanExporter`` is returned, as in 1.0.0.
    :param mask_attributes: extra attribute names to pass to ``mask``, beyond
        the built-in content keys (exact names, or a prefix ending in ``*``).
        Requires ``mask``.
    :raises ConvivaTracingError: if ``mask`` or ``mask_attributes`` is invalid,
        or ``mask_attributes`` is given without ``mask``.
    """
    if mask_attributes is not None and mask is None:
        raise ConvivaTracingError(
            "`mask_attributes` has no effect without `mask`; pass a mask function too."
        )
    exporter = OTLPSpanExporter(endpoint=config.traces_url, headers=dict(config.headers))
    if mask is None:
        return exporter
    return MaskingSpanExporter(exporter, mask, attributes=mask_attributes)
