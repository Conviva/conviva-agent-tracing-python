"""The optional mask hook.

The SDK does not detect or mask PII itself: detection runs once, centrally, in
the Conviva pipeline, where every ingest path is covered and rules change
without a customer upgrade. What the SDK offers is a hook -- a function the
application writes (regex, Presidio, its own DLP) that is called for each
content attribute on every finished span, and on each of its events, just
before export.

Off unless a function is passed: without one, no wrapper is installed and spans
are exported exactly as before.

Why an exporter wrapper and not a span processor: by the time a span reaches
the exporter its attributes are final, including ones OpenLLMetry writes late.
Spans are not mutated in place -- a copy carrying the masked attributes is
exported, so other processors and exporters see the original.

The Python mirror of ``exporters/mask.ts``; the key lists are asserted against
``contract/mask-contract.json`` by both.
"""

from __future__ import annotations

import inspect
import logging
import threading
import time
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any, Optional

from opentelemetry.sdk.trace import Event, ReadableSpan
from opentelemetry.trace import Status
from opentelemetry.sdk.trace.export import SpanExporter, SpanExportResult
from opentelemetry.util.types import AttributeValue

from ..config import CONVERSATION_ID_ATTRIBUTE
from ..errors import ConvivaTracingError

_logger = logging.getLogger(__name__)

#: Exact attribute names that carry prompt, completion, tool or error content.
#: Matched on span attributes and on span-event attributes alike.
#: The key the span's status description is passed to the hook under. Not an
#: attribute: SDKs fill the description from the exception message.
STATUS_DESCRIPTION_KEY = "otel.status_description"

MASK_CONTENT_KEYS: tuple[str, ...] = (
    "gen_ai.input.messages",
    "gen_ai.output.messages",
    "gen_ai.system_instructions",
    "gen_ai.tool.call.arguments",
    "gen_ai.tool.call.result",
    # Legacy gen_ai semconv: carried on gen_ai.content.prompt / .completion events.
    "gen_ai.prompt",
    "gen_ai.completion",
    "traceloop.entity.input",
    "traceloop.entity.output",
    "traceloop.prompt.template",
    # Exception events often echo the input that caused them.
    "exception.message",
    "exception.stacktrace",
    STATUS_DESCRIPTION_KEY,
)

#: Attribute-name prefixes that carry content (OpenLLMetry's indexed and
#: association attributes).
MASK_CONTENT_PREFIXES: tuple[str, ...] = (
    "gen_ai.prompt.",
    "gen_ai.completion.",
    "traceloop.association.properties.",
    "traceloop.prompt.template_variables.",
)

#: Never passed to the hook, even when a prefix matches: Conviva groups spans
#: into conversations by these, so a hook that rewrote them would split or
#: merge conversations.
MASK_NEVER_KEYS: tuple[str, ...] = (
    CONVERSATION_ID_ATTRIBUTE,
    "gen_ai.conversation.id",
    "session.id",
    "traceloop.association.properties.session_id",
    # The Conviva client sensor's ids, copied from baggage: they join the
    # user's session to the agent's spans.
    "c3.client_id",
    "c3.conv_id",
)


@dataclass(frozen=True)
class MaskInput:
    """What the mask hook is called with, once per content attribute.

    A single object rather than positional arguments, so fields can be added
    later without breaking existing hooks.
    """

    #: The attribute name, e.g. ``gen_ai.input.messages``.
    key: str
    #: The attribute value as recorded. Usually a string, often JSON.
    value: AttributeValue
    #: The finished span, as recorded. Read-only.
    span: ReadableSpan
    #: The name of the span event the attribute belongs to (e.g.
    #: ``exception``), or ``None`` for an attribute of the span itself.
    event: str | None = None


#: ``mask(input)`` returns the value to export, or ``None`` to drop the
#: attribute. Must be synchronous and return a valid attribute value (str,
#: bool, int, float, or a homogeneous sequence of one of those). Called on the
#: export thread; keep it fast.
MaskFunction = Callable[[MaskInput], Optional[AttributeValue]]


def _compile_extra_attributes(attributes: Any) -> Callable[[str], bool]:
    """Validate ``mask_attributes`` and turn it into a matcher.

    An entry ending in ``*`` matches every attribute name that starts with the
    text before it (``"input.*"``); any other entry matches that exact name
    (``"input.value"``).

    :raises ConvivaTracingError: unless ``attributes`` is a sequence of
        non-empty strings.
    """
    if attributes is None:
        return lambda _key: False
    if (
        isinstance(attributes, (str, bytes))
        or not isinstance(attributes, Sequence)
        or any(not isinstance(a, str) or not a.strip() for a in attributes)
    ):
        raise ConvivaTracingError(
            "`mask_attributes` must be a sequence of non-empty attribute names."
        )
    exact: set[str] = set()
    prefixes: list[str] = []
    for entry in attributes:
        name = entry.strip()
        if name.endswith("*"):
            prefixes.append(name[:-1])
        else:
            exact.add(name)
    prefix_tuple = tuple(prefixes)
    return lambda key: key in exact or key.startswith(prefix_tuple)


def is_maskable_attribute(key: str, extra_attributes: Sequence[str] | None = None) -> bool:
    """Whether the mask hook is called for an attribute (on a span or a span event).

    ``extra_attributes`` adds names beyond the built-in content keys, in the
    ``mask_attributes`` syntax (exact names, or a prefix ending in ``*``). The
    conversation ids in :data:`MASK_NEVER_KEYS` are never maskable.
    """
    if key in MASK_NEVER_KEYS:
        return False
    if key in MASK_CONTENT_KEYS or key.startswith(MASK_CONTENT_PREFIXES):
        return True
    return extra_attributes is not None and _compile_extra_attributes(extra_attributes)(key)


def _is_async(fn: Any) -> bool:
    return (
        inspect.iscoroutinefunction(fn)
        or inspect.isasyncgenfunction(fn)
        # A callable object with an ``async def __call__``.
        or inspect.iscoroutinefunction(type(fn).__call__)
    )


def _validate_mask(mask: Any) -> None:
    """Raise :class:`ConvivaTracingError` unless ``mask`` is a synchronous callable.

    An async hook could never take effect -- export cannot await it -- so it
    is rejected when it is configured rather than silently dropping content.
    """
    if not callable(mask):
        raise ConvivaTracingError("`mask` must be a callable.")
    if _is_async(mask):
        raise ConvivaTracingError(
            "`mask` must be synchronous; an async function cannot be awaited on the export path."
        )


_PRIMITIVES = (str, bool, int, float)

#: OTLP carries integers as signed 64-bit; anything outside fails the whole
#: export request when it is encoded.
_INT64_MIN, _INT64_MAX = -(2**63), 2**63 - 1


def _is_int64(value: Any) -> bool:
    return not isinstance(value, int) or isinstance(value, bool) or _INT64_MIN <= value <= _INT64_MAX


def _is_attribute_value(value: Any) -> bool:
    """Whether ``value`` is something OTLP can carry as an attribute value."""
    if isinstance(value, _PRIMITIVES):
        return _is_int64(value)
    if isinstance(value, (list, tuple)):
        item_types = {type(item) for item in value if item is not None}
        return (
            len(item_types) <= 1
            and all(issubclass(t, _PRIMITIVES) for t in item_types)
            and all(_is_int64(item) for item in value)
        )
    return False


#: Minimum interval between two warnings about a failing hook.
_WARN_INTERVAL_S = 60.0


class _MaskedEvent(Event):
    """An event carrying masked attributes and the original's dropped count."""

    def __init__(self, source: Event, attributes: Mapping[str, Any]) -> None:
        super().__init__(source.name, MappingProxyType(dict(attributes)), source.timestamp)
        self._dropped = source.dropped_attributes

    @property
    def dropped_attributes(self) -> int:
        return self._dropped


#: Marks a value the hook gave back unchanged.
_UNCHANGED = object()


class _MaskedSpan(ReadableSpan):
    """A copy of a span with masked attributes and events.

    Every other field is the original's, including the dropped attribute,
    event and link counts, which a plain ``ReadableSpan`` would report as 0.
    """

    def __init__(
        self,
        source: ReadableSpan,
        attributes: Mapping[str, Any],
        events: Sequence[Event],
        status: Status,
    ) -> None:
        super().__init__(
            name=source.name,
            context=source.context,
            parent=source.parent,
            resource=source.resource,
            attributes=attributes,
            events=events,
            links=source.links,
            kind=source.kind,
            status=status,
            start_time=source.start_time,
            end_time=source.end_time,
            # The public property is deprecated and warns on access.
            instrumentation_info=getattr(source, "_instrumentation_info", None),
            instrumentation_scope=source.instrumentation_scope,
        )
        self._source = source

    @property
    def dropped_attributes(self) -> int:
        return self._source.dropped_attributes

    @property
    def dropped_events(self) -> int:
        return self._source.dropped_events

    @property
    def dropped_links(self) -> int:
        return self._source.dropped_links


class MaskingSpanExporter(SpanExporter):
    """Wraps an exporter so every span passes through ``mask`` before it is sent.

    :param attributes: extra attribute names to pass to the hook, for
        instrumentation that records content outside the built-in keys -- e.g.
        OpenInference's ``input.value`` / ``output.value``. An entry ending in
        ``*`` is a prefix (``"langfuse.observation.*"``); any other entry is an
        exact name. Adds to the built-in keys, never replaces them;
        conversation ids stay unmaskable.
    :raises ConvivaTracingError: if ``mask`` is not a synchronous callable, or
        ``attributes`` is not a sequence of non-empty strings.
    """

    def __init__(
        self,
        delegate: SpanExporter,
        mask: MaskFunction,
        attributes: Sequence[str] | None = None,
    ) -> None:
        _validate_mask(mask)
        self._is_extra = _compile_extra_attributes(attributes)
        self._delegate = delegate
        self._mask = mask
        self._warn_lock = threading.Lock()
        self._next_warn_at = 0.0
        self._suppressed = 0

    def _is_maskable(self, key: str) -> bool:
        """Built-in content keys plus ``attributes``; never a conversation id."""
        if key in MASK_NEVER_KEYS:
            return False
        return is_maskable_attribute(key) or self._is_extra(key)

    def export(self, spans: Sequence[ReadableSpan]) -> SpanExportResult:
        return self._delegate.export([self._mask_span(span) for span in spans])

    def shutdown(self) -> None:
        self._delegate.shutdown()

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return self._delegate.force_flush(timeout_millis)

    def _mask_span(self, span: ReadableSpan) -> ReadableSpan:
        """The span to export: ``span`` itself when the hook changed nothing."""
        attributes = self._mask_map(span.attributes or {}, span, None)

        events: list[Event] | None = None
        for i, event in enumerate(span.events):
            if not event.attributes:
                continue
            masked = self._mask_map(event.attributes, span, event.name)
            if masked is None:
                continue
            if events is None:
                events = list(span.events)
            events[i] = _MaskedEvent(event, masked)

        # The status description usually repeats the exception message.
        status = span.status
        description = status.description if status is not None else None
        if description:
            new = self._apply_hook(STATUS_DESCRIPTION_KEY, description, span, None)
            if new is not _UNCHANGED:
                # Fails closed: a non-string result drops the description.
                status = Status(status.status_code, new if isinstance(new, str) else None)

        if attributes is None and events is None and status is span.status:
            return span
        return _MaskedSpan(
            span,
            attributes if attributes is not None else (span.attributes or {}),
            events if events is not None else span.events,
            status,
        )

    def _apply_hook(
        self, key: str, value: Any, span: ReadableSpan, event: str | None
    ) -> Any:
        """Call the hook for one value.

        Returns ``_UNCHANGED`` when the hook gave the value back, otherwise the
        value to export (``None`` = drop it). Fails closed: if the hook raises,
        returns an awaitable or returns something that is not an attribute
        value, the result is ``None``.
        """
        try:
            new = self._mask(MaskInput(key=key, value=value, span=span, event=event))
            if inspect.isawaitable(new):
                close = getattr(new, "close", None)
                if close:
                    close()  # avoid "coroutine was never awaited"
                raise TypeError("returned an awaitable")
            if new is not None and not _is_attribute_value(new):
                raise TypeError("returned a non-attribute value")
        except Exception as exc:  # noqa: BLE001 -- customer code, fail closed
            self._warn(key, exc)
            return None
        return _UNCHANGED if new is value else new

    def _mask_map(
        self, original: Mapping[str, Any], span: ReadableSpan, event: str | None
    ) -> dict[str, Any] | None:
        """Apply the hook to one attribute map.

        Fails closed: if the hook raises, returns an awaitable or returns
        something that is not an attribute value, that attribute is dropped and
        the span still exports. Returns ``None`` when nothing changed, so
        untouched spans are not copied.
        """
        out: dict[str, Any] | None = None

        for key, value in original.items():
            if value is None or not self._is_maskable(key):
                continue
            new = self._apply_hook(key, value, span, event)
            if new is _UNCHANGED:
                continue
            if out is None:
                out = dict(original)
            if new is None:
                del out[key]
            else:
                out[key] = new

        return out

    def _warn(self, key: str, exc: Exception) -> None:
        """Log a failing hook at most once a minute.

        Only the attribute key and the exception's type are logged -- never its
        message, which may quote the very content the hook was meant to mask.
        """
        now = time.monotonic()
        with self._warn_lock:
            if now < self._next_warn_at:
                self._suppressed += 1
                return
            suppressed, self._suppressed = self._suppressed, 0
            self._next_warn_at = now + _WARN_INTERVAL_S
        more = f" ({suppressed} more since the last warning)" if suppressed else ""
        _logger.warning(
            "Conviva mask failed for attribute %r (%s); dropped it%s.",
            key,
            type(exc).__name__,
            more,
        )
