"""``conviva-otlp-exporter`` -- the Conviva transport layer.

Resolves the gateway destination and routing headers, builds the OTLP
http/protobuf trace exporter, and supplies the span processors that stamp the
project and conversation ids the gateway correlates on.

Traces only: the gateway serves ``/v1/traces``, and nothing here exports
metrics or logs.

Depends on no vendor SDK -- no OpenLLMetry, no Langfuse -- so it can be used
on its own underneath whichever instrumentation library an application already
has.
"""

from .config import (
    CONVERSATION_ID_ATTRIBUTE,
    CUSTOMER_KEY_ENV,
    ENDPOINT_ENV,
    GATEWAY_DOMAIN,
    PROJECT_ID_ATTRIBUTE,
    PROJECT_ID_ENV,
    PROJECT_ID_HEADER,
    TRACES_PATH,
    ResolvedConfig,
    normalize_endpoint,
    parse_key_pairs,
    resolve_config,
)
from .errors import ConvivaTracingError
from .exporters import (
    MASK_CONTENT_KEYS,
    MASK_CONTENT_PREFIXES,
    MASK_NEVER_KEYS,
    STATUS_DESCRIPTION_KEY,
    MaskFunction,
    MaskInput,
    MaskingSpanExporter,
    create_trace_exporter,
    is_maskable_attribute,
)
from .processors import (
    ASSOCIATION_PROPERTY_PREFIX,
    DEFAULT_BAGGAGE_KEYS,
    DEFAULT_SOURCE_ATTRIBUTES,
    GEN_AI_CONVERSATION_ID_ATTRIBUTE,
    AttributeSpanProcessor,
    CompositeSpanProcessor,
    ConversationIdSpanProcessor,
    ProjectIdSpanProcessor,
    create_conviva_span_processors,
)

__version__ = "1.2.0"

__all__ = [
    "ASSOCIATION_PROPERTY_PREFIX",
    "CONVERSATION_ID_ATTRIBUTE",
    "CUSTOMER_KEY_ENV",
    "DEFAULT_BAGGAGE_KEYS",
    "DEFAULT_SOURCE_ATTRIBUTES",
    "ENDPOINT_ENV",
    "GATEWAY_DOMAIN",
    "GEN_AI_CONVERSATION_ID_ATTRIBUTE",
    "MASK_CONTENT_KEYS",
    "MASK_CONTENT_PREFIXES",
    "MASK_NEVER_KEYS",
    "STATUS_DESCRIPTION_KEY",
    "PROJECT_ID_ATTRIBUTE",
    "PROJECT_ID_ENV",
    "PROJECT_ID_HEADER",
    "TRACES_PATH",
    "AttributeSpanProcessor",
    "CompositeSpanProcessor",
    "ConversationIdSpanProcessor",
    "ConvivaTracingError",
    "MaskFunction",
    "MaskInput",
    "MaskingSpanExporter",
    "ProjectIdSpanProcessor",
    "ResolvedConfig",
    "__version__",
    "create_conviva_span_processors",
    "create_trace_exporter",
    "is_maskable_attribute",
    "normalize_endpoint",
    "parse_key_pairs",
    "resolve_config",
]
