from __future__ import annotations

from typing import Optional

import opentelemetry.trace as trace_api

from .config import Config
from .processor import BaggageSpanProcessor
from .propagation import ensure_baggage_propagator


def install(
    tracer_provider=None, config: Optional[Config] = None
) -> Optional[BaggageSpanProcessor]:
    """Attach a :class:`BaggageSpanProcessor` and register the baggage propagator.

    Idempotent: repeated calls against the same provider return the existing
    processor rather than adding a second one. Providers that do not support
    ``add_span_processor`` (e.g. the API's no-op / proxy provider) are handled
    gracefully; the propagator is still registered.
    """
    provider = tracer_provider
    if provider is None:
        provider = trace_api.get_tracer_provider()

    processor: Optional[BaggageSpanProcessor] = None

    if getattr(provider, "_conviva_baggage_installed", False):
        ensure_baggage_propagator()
        return getattr(provider, "_conviva_baggage_processor", None)

    cfg = config if config is not None else None

    try:
        add_span_processor = provider.add_span_processor
    except AttributeError:
        add_span_processor = None

    if add_span_processor is not None:
        try:
            processor = BaggageSpanProcessor(cfg)
            add_span_processor(processor)
            try:
                provider._conviva_baggage_installed = True  # noqa: SLF001
                provider._conviva_baggage_processor = processor  # noqa: SLF001
            except Exception:  # noqa: BLE001 - marker is best-effort
                pass
        except Exception as exc:  # noqa: BLE001
            processor = None
            _log_warning(cfg, "could not attach BaggageSpanProcessor: %s", exc)
    else:
        _log_warning(
            cfg,
            "tracer provider %r does not support add_span_processor; "
            "skipping span processor attachment",
            type(provider).__name__,
        )

    ensure_baggage_propagator()

    return processor


def _log_warning(config: Optional[Config], msg: str, *args) -> None:
    logger = config.logger if config is not None else None
    if logger is not None:
        logger.warning(msg, *args)
