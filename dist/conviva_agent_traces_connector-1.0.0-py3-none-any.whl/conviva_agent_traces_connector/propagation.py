from __future__ import annotations

from opentelemetry.baggage.propagation import W3CBaggagePropagator
from opentelemetry.propagate import get_global_textmap, set_global_textmap
from opentelemetry.propagators.composite import CompositePropagator
from opentelemetry.trace.propagation.tracecontext import (
    TraceContextTextMapPropagator,
)


def ensure_baggage_propagator() -> None:
    """Ensure the global propagator composes W3C baggage + trace context.

    Merges the required propagators into the existing global propagator without
    dropping any already-registered propagators or duplicating types.
    """
    current = get_global_textmap()

    required_types = (W3CBaggagePropagator, TraceContextTextMapPropagator)

    try:
        if isinstance(current, CompositePropagator):
            propagators = list(current._propagators)  # noqa: SLF001
        else:
            propagators = [current]

        existing_types = {type(p) for p in propagators}
        for prop_type in required_types:
            if prop_type not in existing_types:
                propagators.append(prop_type())

        set_global_textmap(CompositePropagator(propagators))
    except Exception:  # noqa: BLE001 - stay defensive on introspection failure
        set_global_textmap(CompositePropagator([current, W3CBaggagePropagator()]))
