from .config import DEFAULT_CONFIG, Config
from .install import install
from .processor import BaggageSpanProcessor
from .propagation import ensure_baggage_propagator

__version__ = "1.0.0"

__all__ = [
    "install",
    "BaggageSpanProcessor",
    "Config",
    "DEFAULT_CONFIG",
    "ensure_baggage_propagator",
    "__version__",
]
