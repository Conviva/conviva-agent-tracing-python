from __future__ import annotations

from typing import Optional

from opentelemetry.baggage import get_all
from opentelemetry.sdk.trace import SpanProcessor

from .config import DEFAULT_CONFIG, Config


class BaggageSpanProcessor(SpanProcessor):
    """Copies allowlisted W3C baggage entries onto every span at start time."""

    def __init__(self, config: Optional[Config] = None) -> None:
        self._config = config if config is not None else DEFAULT_CONFIG

    @property
    def config(self) -> Config:
        return self._config

    def on_start(self, span, parent_context=None) -> None:
        try:
            for key, value in get_all(context=parent_context).items():
                if self._config.matches(key):
                    span.set_attribute(self._config.attr_key(key), str(value))
        except Exception as exc:  # noqa: BLE001 - never raise from on_start
            if self._config.logger is not None:
                self._config.logger.warning(
                    "BaggageSpanProcessor.on_start failed: %s", exc
                )

    def on_end(self, span) -> None:
        pass

    def shutdown(self) -> None:
        pass

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return True
