from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional, Tuple


@dataclass(frozen=True)
class Config:
    """Configuration for baggage-to-span-attribute copying.

    ``allowlist`` entries are matched two ways:
      * an exact match against the baggage key, or
      * a prefix match, but only for entries that end in ``.`` (e.g. ``c3.``
        matches ``c3.client_id`` but not ``c3client_id``).
    """

    allowlist: Tuple[str, ...] = ("c3.",)
    attribute_prefix: str = ""
    logger: Optional[logging.Logger] = None

    def matches(self, key: str) -> bool:
        for entry in self.allowlist:
            if key == entry:
                return True
            if entry.endswith(".") and key.startswith(entry):
                return True
        return False

    def attr_key(self, key: str) -> str:
        return self.attribute_prefix + key


DEFAULT_CONFIG = Config()
